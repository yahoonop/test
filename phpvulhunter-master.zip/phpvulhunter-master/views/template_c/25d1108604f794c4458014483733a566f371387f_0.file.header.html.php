<?php /* Smarty version 3.1.23, created on 2015-05-27 09:17:14
         compiled from "views/template/header.html" */ ?>
<?php
/*%%SmartyHeaderCode:1523355658b9ae9f589_97592936%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25d1108604f794c4458014483733a566f371387f' => 
    array (
      0 => 'views/template/header.html',
      1 => 1432513732,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1523355658b9ae9f589_97592936',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_55658b9aea0fb6_73933876',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55658b9aea0fb6_73933876')) {
function content_55658b9aea0fb6_73933876 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '1523355658b9ae9f589_97592936';
?>
<head>
	<meta charset="utf-8">
	<link type="text/css" rel="stylesheet" href="views/static/css/index.css">
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/jquery-1.8.3.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/phpvulhunter.js"><?php echo '</script'; ?>
>
</head><?php }
}
?>