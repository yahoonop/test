<?php /* Smarty version 3.1.23, created on 2015-05-21 06:30:12
         compiled from "views/template/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:29021555d5f542eb814_24476740%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8ad47a34110551e1bf46e29d266d0841a95757d3' => 
    array (
      0 => 'views/template/footer.html',
      1 => 1432181814,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29021555d5f542eb814_24476740',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_555d5f542ee432_13742947',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_555d5f542ee432_13742947')) {
function content_555d5f542ee432_13742947 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '29021555d5f542eb814_24476740';
?>
<div class="footer">
	<div class="filepath">
		<span>File Path : </span>
		<a id="path" href="#" target="_blank">
			<abbr title="#"></abbr>
		</a>
	</div>
	<div class="info">
        ©2015
        <a target="_blank" href="https://github.com/OneSourceCat/phpvulhunter.git">
        	<abbr title="访问我们的GitHub.">SafeCat Team</abbr>
        </a>
        . All Rights Reserved.
    </div>
      <!-- <li>
        Contact:
        <a href="mailto:chongrui123@gmail.com"><abbr title="联系我们">chongrui123@gmail.com</a></abbr>
      </li> -->
</div><?php }
}
?>