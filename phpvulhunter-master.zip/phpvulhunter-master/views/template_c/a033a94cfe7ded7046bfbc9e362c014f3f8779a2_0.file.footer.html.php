<?php /* Smarty version 3.1.23, created on 2019-08-11 19:32:52
         compiled from "views/template/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:14913470855d50514433d571_59642477%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a033a94cfe7ded7046bfbc9e362c014f3f8779a2' => 
    array (
      0 => 'views/template/footer.html',
      1 => 1433926915,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14913470855d50514433d571_59642477',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_5d505144364672_94651412',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d505144364672_94651412')) {
function content_5d505144364672_94651412 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '14913470855d50514433d571_59642477';
?>

<div class="footer">
	<div class="count">
	</div>
	
	<div class="info">
        ©2015
        <a target="_blank" href="https://github.com/OneSourceCat/phpvulhunter.git">
        	<abbr title="访问我们的GitHub.">SafeCat Team</abbr>
        </a>
        . All Rights Reserved.
    </div>
</div><?php }
}
?>