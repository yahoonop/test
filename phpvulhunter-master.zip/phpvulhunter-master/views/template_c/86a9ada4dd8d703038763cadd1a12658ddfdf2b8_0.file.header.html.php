<?php /* Smarty version 3.1.23, created on 2015-05-28 13:51:00
         compiled from "views/template/header.html" */ ?>
<?php
/*%%SmartyHeaderCode:194435567012465f740_83129476%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '86a9ada4dd8d703038763cadd1a12658ddfdf2b8' => 
    array (
      0 => 'views/template/header.html',
      1 => 1432813096,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '194435567012465f740_83129476',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_55670124667441_16395472',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55670124667441_16395472')) {
function content_55670124667441_16395472 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '194435567012465f740_83129476';
?>
<head>
	<meta charset="utf-8">
	<link type="text/css" rel="stylesheet" href="views/static/css/index.css">
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/jquery-1.8.3.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/phpvulhunter.js"><?php echo '</script'; ?>
>
</head><?php }
}
?>