<?php /* Smarty version 3.1.23, created on 2015-05-28 13:51:00
         compiled from "views/template/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:2014255670124e896b2_73278055%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '79c3e325eb3f1ef2b7a709df7f96006555a11bed' => 
    array (
      0 => 'views/template/footer.html',
      1 => 1432813096,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2014255670124e896b2_73278055',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_55670124e8d534_60524277',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55670124e8d534_60524277')) {
function content_55670124e8d534_60524277 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '2014255670124e896b2_73278055';
?>

<div class="footer">
	<div class="count">
	</div>
	
	<div class="info">
        ©2015
        <a target="_blank" href="https://github.com/OneSourceCat/phpvulhunter.git">
        	<abbr title="访问我们的GitHub.">SafeCat Team</abbr>
        </a>
        . All Rights Reserved.
    </div>
</div><?php }
}
?>