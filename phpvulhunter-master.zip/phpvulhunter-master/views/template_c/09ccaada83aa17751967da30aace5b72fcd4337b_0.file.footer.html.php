<?php /* Smarty version 3.1.23, created on 2015-05-27 09:17:15
         compiled from "views/template/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:3022855658b9b16f414_60071859%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '09ccaada83aa17751967da30aace5b72fcd4337b' => 
    array (
      0 => 'views/template/footer.html',
      1 => 1432513732,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3022855658b9b16f414_60071859',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_55658b9b170f02_59259383',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55658b9b170f02_59259383')) {
function content_55658b9b170f02_59259383 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '3022855658b9b16f414_60071859';
?>

<div class="footer">
	<div class="count">
	</div>
	
	<div class="info">
        ©2015
        <a target="_blank" href="https://github.com/OneSourceCat/phpvulhunter.git">
        	<abbr title="访问我们的GitHub.">SafeCat Team</abbr>
        </a>
        . All Rights Reserved.
    </div>
</div><?php }
}
?>