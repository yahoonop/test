<?php /* Smarty version 3.1.23, created on 2015-05-20 15:28:32
         compiled from "views/template/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:32304555ca820c48b56_48417846%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ec6d64f46b2fda1d7f25e956a12e5e913758afdc' => 
    array (
      0 => 'views/template/footer.html',
      1 => 1432124262,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32304555ca820c48b56_48417846',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_555ca820c50e25_01716726',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_555ca820c50e25_01716726')) {
function content_555ca820c50e25_01716726 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '32304555ca820c48b56_48417846';
?>
<div class="footer">
	<div class="filepath">
		<span>File Path : </span>
		<a id="path" href="#" target="_blank">
			<abbr title="打开文件"></abbr>
		</a>
	</div>
	<div class="info">
        ©2015
        <a target="_blank" href="https://github.com/OneSourceCat/phpvulhunter.git">
        	<abbr title="访问我们的GitHub.">SafeCat Team</abbr>
        </a>
        . All Rights Reserved.
    </div>
      <!-- <li>
        Contact:
        <a href="mailto:chongrui123@gmail.com"><abbr title="联系我们">chongrui123@gmail.com</a></abbr>
      </li> -->
</div><?php }
}
?>