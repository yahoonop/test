<?php /* Smarty version 3.1.23, created on 2015-05-19 15:38:35
         compiled from "views/template/header.html" */ ?>
<?php
/*%%SmartyHeaderCode:25980555b58fb2c4a49_08904637%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '252bd0ba146874a34e3ac4345eef938bb5c17b82' => 
    array (
      0 => 'views/template/header.html',
      1 => 1432022462,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25980555b58fb2c4a49_08904637',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_555b58fb2c9bf8_88227629',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_555b58fb2c9bf8_88227629')) {
function content_555b58fb2c9bf8_88227629 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '25980555b58fb2c4a49_08904637';
?>
<head>
	<meta charset="utf-8">
	<link type="text/css" rel="stylesheet" href="views/static/css/index.css">
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/jquery-1.8.3.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/phpvulhunter.js"><?php echo '</script'; ?>
>
</head><?php }
}
?>