<?php /* Smarty version 3.1.23, created on 2015-05-21 06:30:12
         compiled from "views/template/header.html" */ ?>
<?php
/*%%SmartyHeaderCode:20999555d5f542d36c3_19289923%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '823fb77b140d9f097d9abd81345a6868cbf7f3bb' => 
    array (
      0 => 'views/template/header.html',
      1 => 1432181814,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20999555d5f542d36c3_19289923',
  'has_nocache_code' => false,
  'version' => '3.1.23',
  'unifunc' => 'content_555d5f542d6714_63139976',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_555d5f542d6714_63139976')) {
function content_555d5f542d6714_63139976 ($_smarty_tpl) {
?>
<?php
$_smarty_tpl->properties['nocache_hash'] = '20999555d5f542d36c3_19289923';
?>
<head>
	<meta charset="utf-8">
	<link type="text/css" rel="stylesheet" href="views/static/css/index.css">
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/jquery-1.8.3.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 type="text/javascript" src="views/static/js/phpvulhunter.js"><?php echo '</script'; ?>
>
</head><?php }
}
?>